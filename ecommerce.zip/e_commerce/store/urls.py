from django.urls import path
from store.views import home,productpage,add_cart,cart_detail,cart_remove,cart_remove_product,signupView,signinView,signoutView,search

urlpatterns=[
    path('home.',home,name='home'),
    path('category/<slug:category_slug>',home,name='products_by_category'),
    path('category/<slug:category_slug>/<slug:product_slug>',productpage,name='product_detail'),
    path('cart/add/<int:product_id>',add_cart,name='add_cart'),
    path('cart',cart_detail,name='cart_detail'),
    path('cart/remove/<int:product_id>',cart_remove,name='cart_remove'),
    path('cart/remove_product/<int:product_id>',cart_remove_product,name='cart_remove_product'),
    path('account/signup/',signupView, name='signup'),
    path('',signinView,name='signin'),
    path('account/signout/',signoutView,name='signout'),
    path('search/',search,name='search'),
]